#  Saudi Plant Safety detector > 2025-09-03 11:48am
https://universe.roboflow.com/wateen-f/saudi-plant-safety-detector-lqu25

Provided by a Roboflow user
License: CC BY 4.0

